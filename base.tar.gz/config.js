import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import fs from 'fs'

//owner
global.owner = [
['5214774444444'],
['593968585383'],
['573226873710'],
['595975711894'],
['5219999699999']
]

//Información 
globalThis.info = {
wm: "𝙲𝙶𝙳៝𝙿𝚁͢𝚅₃₋₄₄",
vs: "1.0.0 (personalizado)",
packname: "𝙲𝙶𝙳៝𝙿𝚁͢𝚅₃₋₄₄",
author: "by china & elrebelde21",
ig: "https://www.instagram.com/itschinita_official"
}

//----------------------------------------------------

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
